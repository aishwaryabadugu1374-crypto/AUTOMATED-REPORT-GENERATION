"""
Sales Data Analyzer & PDF Report Generator
-------------------------------------------
Reads a CSV file, analyzes the data, and produces a formatted PDF report
using ReportLab.

Usage:
    python report_generator.py                   # uses default sales_data.csv
    python report_generator.py my_data.csv       # uses a custom file
"""

import csv
import sys
import os
from collections import defaultdict
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_RIGHT


# ── 1. DATA LOADING ──────────────────────────────────────────────────────────

def load_csv(filepath: str) -> list[dict]:
    """Read CSV and return a list of row-dicts with numeric fields cast."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Data file not found: {filepath}")

    rows = []
    with open(filepath, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({
                "Month":      row["Month"].strip(),
                "Product":    row["Product"].strip(),
                "Units_Sold": int(row["Units_Sold"]),
                "Revenue":    float(row["Revenue"]),
                "Cost":       float(row["Cost"]),
            })
    return rows


# ── 2. ANALYSIS ───────────────────────────────────────────────────────────────

def analyze(rows: list[dict]) -> dict:
    """Derive summary statistics from raw rows."""
    total_revenue  = sum(r["Revenue"]    for r in rows)
    total_cost     = sum(r["Cost"]       for r in rows)
    total_units    = sum(r["Units_Sold"] for r in rows)
    total_profit   = total_revenue - total_cost
    profit_margin  = (total_profit / total_revenue * 100) if total_revenue else 0

    # Per-product aggregates
    by_product: dict[str, dict] = defaultdict(lambda: {"units": 0, "revenue": 0.0, "cost": 0.0})
    for r in rows:
        p = by_product[r["Product"]]
        p["units"]   += r["Units_Sold"]
        p["revenue"] += r["Revenue"]
        p["cost"]    += r["Cost"]

    product_summary = []
    for product, vals in sorted(by_product.items()):
        profit = vals["revenue"] - vals["cost"]
        margin = (profit / vals["revenue"] * 100) if vals["revenue"] else 0
        product_summary.append({
            "Product": product,
            "Units":   vals["units"],
            "Revenue": vals["revenue"],
            "Profit":  profit,
            "Margin":  margin,
        })

    # Best & worst performers
    best_product  = max(product_summary, key=lambda x: x["Revenue"])
    worst_product = min(product_summary, key=lambda x: x["Revenue"])

    # Monthly revenue
    monthly: dict[str, float] = defaultdict(float)
    month_order = []
    for r in rows:
        if r["Month"] not in month_order:
            month_order.append(r["Month"])
        monthly[r["Month"]] += r["Revenue"]

    monthly_revenue = [{"Month": m, "Revenue": monthly[m]} for m in month_order]

    # Month-over-month growth
    growth = []
    for i in range(1, len(monthly_revenue)):
        prev = monthly_revenue[i - 1]["Revenue"]
        curr = monthly_revenue[i]["Revenue"]
        pct  = ((curr - prev) / prev * 100) if prev else 0
        growth.append({"Month": monthly_revenue[i]["Month"], "Growth_%": pct})

    avg_monthly_growth = sum(g["Growth_%"] for g in growth) / len(growth) if growth else 0

    return {
        "total_revenue":      total_revenue,
        "total_cost":         total_cost,
        "total_profit":       total_profit,
        "total_units":        total_units,
        "profit_margin":      profit_margin,
        "product_summary":    product_summary,
        "best_product":       best_product,
        "worst_product":      worst_product,
        "monthly_revenue":    monthly_revenue,
        "avg_monthly_growth": avg_monthly_growth,
        "raw_rows":           rows,
    }


# ── 3. PDF REPORT ─────────────────────────────────────────────────────────────

BRAND_BLUE  = colors.HexColor("#1A3C6E")
BRAND_TEAL  = colors.HexColor("#0D7D7A")
LIGHT_GRAY  = colors.HexColor("#F2F4F7")
MID_GRAY    = colors.HexColor("#D1D5DB")
WHITE       = colors.white
DARK_TEXT   = colors.HexColor("#1F2937")


def _fmt_currency(value: float) -> str:
    return f"${value:,.0f}"

def _fmt_pct(value: float) -> str:
    sign = "+" if value >= 0 else ""
    return f"{sign}{value:.1f}%"


def build_styles() -> dict:
    base = getSampleStyleSheet()

    styles = {
        "cover_title": ParagraphStyle(
            "cover_title", parent=base["Title"],
            fontSize=28, textColor=WHITE, spaceAfter=6,
            alignment=TA_CENTER, fontName="Helvetica-Bold"
        ),
        "cover_sub": ParagraphStyle(
            "cover_sub", parent=base["Normal"],
            fontSize=12, textColor=colors.HexColor("#BDD7EE"),
            alignment=TA_CENTER, fontName="Helvetica"
        ),
        "section_heading": ParagraphStyle(
            "section_heading", parent=base["Heading1"],
            fontSize=14, textColor=BRAND_BLUE, spaceBefore=18,
            spaceAfter=6, fontName="Helvetica-Bold",
            borderPad=4
        ),
        "body": ParagraphStyle(
            "body", parent=base["Normal"],
            fontSize=10, textColor=DARK_TEXT, spaceAfter=6,
            fontName="Helvetica", leading=15
        ),
        "kpi_label": ParagraphStyle(
            "kpi_label", parent=base["Normal"],
            fontSize=9, textColor=colors.HexColor("#6B7280"),
            alignment=TA_CENTER, fontName="Helvetica"
        ),
        "kpi_value": ParagraphStyle(
            "kpi_value", parent=base["Normal"],
            fontSize=20, textColor=BRAND_BLUE,
            alignment=TA_CENTER, fontName="Helvetica-Bold"
        ),
        "table_header": ParagraphStyle(
            "table_header", parent=base["Normal"],
            fontSize=9, textColor=WHITE,
            alignment=TA_CENTER, fontName="Helvetica-Bold"
        ),
        "table_cell": ParagraphStyle(
            "table_cell", parent=base["Normal"],
            fontSize=9, textColor=DARK_TEXT,
            alignment=TA_CENTER, fontName="Helvetica"
        ),
        "footer": ParagraphStyle(
            "footer", parent=base["Normal"],
            fontSize=8, textColor=colors.gray,
            alignment=TA_CENTER, fontName="Helvetica-Oblique"
        ),
        "insight": ParagraphStyle(
            "insight", parent=base["Normal"],
            fontSize=10, textColor=DARK_TEXT, spaceAfter=4,
            fontName="Helvetica", leading=14,
            leftIndent=12, bulletIndent=0
        ),
    }
    return styles


def _kpi_table(kpis: list[tuple[str, str]], styles: dict) -> Table:
    """Render a row of KPI boxes."""
    headers = [Paragraph(label, styles["kpi_label"]) for label, _ in kpis]
    values  = [Paragraph(value, styles["kpi_value"]) for _, value in kpis]

    col_w = (6.5 * inch) / len(kpis)
    t = Table([headers, values], colWidths=[col_w] * len(kpis), rowHeights=[20, 36])
    t.setStyle(TableStyle([
        ("BACKGROUND",  (0, 0), (-1, -1), LIGHT_GRAY),
        ("ROUNDEDCORNERS", [6]),
        ("BOX",         (0, 0), (-1, -1), 0.5, MID_GRAY),
        ("INNERGRID",   (0, 0), (-1, -1), 0.5, MID_GRAY),
        ("TOPPADDING",  (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _data_table(header: list[str], rows: list[list], styles: dict,
                col_widths: list[float] = None) -> Table:
    """Generic styled data table."""
    header_row = [Paragraph(h, styles["table_header"]) for h in header]
    data_rows  = [
        [Paragraph(str(cell), styles["table_cell"]) for cell in row]
        for row in rows
    ]

    all_rows = [header_row] + data_rows
    if col_widths is None:
        col_widths = [6.5 * inch / len(header)] * len(header)

    t = Table(all_rows, colWidths=col_widths, repeatRows=1)

    ts = TableStyle([
        # Header
        ("BACKGROUND",    (0, 0), (-1, 0), BRAND_BLUE),
        ("TEXTCOLOR",     (0, 0), (-1, 0), WHITE),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 9),
        ("TOPPADDING",    (0, 0), (-1, 0), 8),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
        # Body
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 9),
        ("TOPPADDING",    (0, 1), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 6),
        ("GRID",          (0, 0), (-1, -1), 0.4, MID_GRAY),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
    ])
    # Alternating row shading
    for i in range(1, len(data_rows) + 1):
        if i % 2 == 0:
            ts.add("BACKGROUND", (0, i), (-1, i), LIGHT_GRAY)
        else:
            ts.add("BACKGROUND", (0, i), (-1, i), WHITE)

    t.setStyle(ts)
    return t


def generate_pdf(stats: dict, output_path: str = "sales_report.pdf") -> str:
    """Build the full PDF report and return its path."""
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
        title="Sales Performance Report",
        author="Report Generator",
    )

    styles = build_styles()
    story  = []
    now    = datetime.now().strftime("%B %d, %Y")

    # ── COVER BANNER ──────────────────────────────────────────────────────────
    cover_data = [[
        Paragraph("SALES PERFORMANCE REPORT", styles["cover_title"]),
        Paragraph(f"Generated on {now}", styles["cover_sub"]),
    ]]
    cover_table = Table(cover_data, colWidths=[6.5 * inch])
    cover_table.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), BRAND_BLUE),
        ("TOPPADDING",    (0, 0), (-1, -1), 24),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 24),
        ("ROUNDEDCORNERS", [8]),
    ]))
    story.append(cover_table)
    story.append(Spacer(1, 18))

    # ── EXECUTIVE SUMMARY ─────────────────────────────────────────────────────
    story.append(Paragraph("Executive Summary", styles["section_heading"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_TEAL, spaceAfter=8))

    kpis = [
        ("Total Revenue",  _fmt_currency(stats["total_revenue"])),
        ("Total Profit",   _fmt_currency(stats["total_profit"])),
        ("Profit Margin",  _fmt_pct(stats["profit_margin"])),
        ("Units Sold",     f"{stats['total_units']:,}"),
    ]
    story.append(_kpi_table(kpis, styles))
    story.append(Spacer(1, 10))

    story.append(Paragraph(
        f"Over the reporting period the business generated "
        f"<b>{_fmt_currency(stats['total_revenue'])}</b> in revenue at an average "
        f"monthly growth rate of <b>{_fmt_pct(stats['avg_monthly_growth'])}</b>. "
        f"The top-performing product was <b>{stats['best_product']['Product']}</b>, "
        f"contributing <b>{_fmt_currency(stats['best_product']['Revenue'])}</b> in revenue.",
        styles["body"]
    ))

    # ── PRODUCT PERFORMANCE ───────────────────────────────────────────────────
    story.append(Paragraph("Product Performance", styles["section_heading"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_TEAL, spaceAfter=8))

    prod_header = ["Product", "Units Sold", "Revenue", "Profit", "Margin"]
    prod_rows   = [
        [
            p["Product"],
            f"{p['Units']:,}",
            _fmt_currency(p["Revenue"]),
            _fmt_currency(p["Profit"]),
            _fmt_pct(p["Margin"]),
        ]
        for p in stats["product_summary"]
    ]
    col_w = [1.5*inch, 1.0*inch, 1.2*inch, 1.2*inch, 1.0*inch]
    story.append(_data_table(prod_header, prod_rows, styles, col_widths=col_w))
    story.append(Spacer(1, 10))

    # ── MONTHLY REVENUE TREND ─────────────────────────────────────────────────
    story.append(Paragraph("Monthly Revenue Trend", styles["section_heading"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_TEAL, spaceAfter=8))

    monthly_header = ["Month", "Revenue", "vs. Prior Month"]
    mr = stats["monthly_revenue"]
    monthly_rows = []
    for i, m in enumerate(mr):
        if i == 0:
            delta = "—"
        else:
            prev  = mr[i - 1]["Revenue"]
            pct   = (m["Revenue"] - prev) / prev * 100
            delta = _fmt_pct(pct)
        monthly_rows.append([m["Month"], _fmt_currency(m["Revenue"]), delta])

    col_w2 = [2.0*inch, 2.0*inch, 2.5*inch]
    story.append(_data_table(monthly_header, monthly_rows, styles, col_widths=col_w2))
    story.append(Spacer(1, 10))

    # ── RAW DATA ──────────────────────────────────────────────────────────────
    story.append(Paragraph("Detailed Transaction Data", styles["section_heading"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_TEAL, spaceAfter=8))

    raw_header = ["Month", "Product", "Units", "Revenue", "Cost", "Profit"]
    raw_rows   = [
        [
            r["Month"],
            r["Product"],
            f"{r['Units_Sold']:,}",
            _fmt_currency(r["Revenue"]),
            _fmt_currency(r["Cost"]),
            _fmt_currency(r["Revenue"] - r["Cost"]),
        ]
        for r in stats["raw_rows"]
    ]
    col_w3 = [1.0*inch, 0.9*inch, 0.7*inch, 1.1*inch, 1.1*inch, 1.1*inch]
    story.append(_data_table(raw_header, raw_rows, styles, col_widths=col_w3))
    story.append(Spacer(1, 14))

    # ── KEY INSIGHTS ──────────────────────────────────────────────────────────
    story.append(Paragraph("Key Insights", styles["section_heading"]))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_TEAL, spaceAfter=8))

    insights = [
        f"<b>Revenue Growth:</b> Average month-over-month growth of "
        f"{_fmt_pct(stats['avg_monthly_growth'])}, signalling strong upward momentum.",

        f"<b>Best Performer:</b> {stats['best_product']['Product']} leads in revenue "
        f"at {_fmt_currency(stats['best_product']['Revenue'])} with a "
        f"{_fmt_pct(stats['best_product']['Margin'])} profit margin.",

        f"<b>Lowest Revenue:</b> {stats['worst_product']['Product']} generated "
        f"{_fmt_currency(stats['worst_product']['Revenue'])} — consider targeted "
        f"promotions or pricing review.",

        f"<b>Profitability:</b> Overall profit margin stands at "
        f"{_fmt_pct(stats['profit_margin'])}, reflecting healthy cost management.",
    ]
    for text in insights:
        story.append(Paragraph(f"• {text}", styles["insight"]))
    story.append(Spacer(1, 10))

    # ── FOOTER NOTE ───────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "This report was auto-generated by report_generator.py. "
        "All figures are derived from the source CSV file.",
        styles["footer"]
    ))

    doc.build(story)
    return output_path


# ── 4. MAIN ENTRY POINT ───────────────────────────────────────────────────────

def main():
    csv_path    = sys.argv[1] if len(sys.argv) > 1 else "sales_data.csv"
    output_path = "sales_report.pdf"

    print(f"[1/3] Loading data from '{csv_path}' ...")
    rows = load_csv(csv_path)
    print(f"      Loaded {len(rows)} records.")

    print("[2/3] Analysing data ...")
    stats = analyze(rows)
    print(f"      Total revenue : {_fmt_currency(stats['total_revenue'])}")
    print(f"      Total profit  : {_fmt_currency(stats['total_profit'])}")
    print(f"      Profit margin : {_fmt_pct(stats['profit_margin'])}")

    print(f"[3/3] Generating PDF report → '{output_path}' ...")
    path = generate_pdf(stats, output_path)
    print(f"      Done! Report saved to: {path}")


if __name__ == "__main__":
    main()
